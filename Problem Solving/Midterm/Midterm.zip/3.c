#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main() {



    return 0;
}