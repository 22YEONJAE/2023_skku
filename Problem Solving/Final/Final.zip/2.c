#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int arr[20];
int sum = 0;
int no[6000][10];
int res[6000];

void swap(int i , int j)
{
    int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = arr[i];
}

int main() {
    
    int j = 0;
    for(int i = 0 ; i < 10; i++){
        scanf("%d", &arr[i]);
        if(arr[i] != 0) {
            sum += arr[i];
            arr[j] = i;
            j++;
        }
    }

    

    int fact = 1;
    for(int i = sum; i > 1; i --) {
        fact *= i;
    }

    int cnt = 0;
    for(int i = 0 ; i < sum - 2; i ++) {
        for(int j = i + 1; j < sum-1; j ++){
            swap(i, j);

        }
    }

    for(int i = 0 ; i<6; i ++) {
        for(j = 0 ; j < 3; j ++) {
            printf("%d", no[i][j]);
        }
        printf("\n");
    }
    


    

    return 0;
}